package ejercicioA;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
	    String carpetaPersonal = System.getProperty("user.home");
	    File archivo = new File("Ficheros\\rutas.txt");

	    try {
	        BufferedReader br = new BufferedReader(new FileReader(archivo));
	        String linea;
	        while ((linea = br.readLine()) != null) {
	            new File(carpetaPersonal+"\\"+linea).mkdir();
	        }
	        br.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

}


